<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$messages = array(
	1=>'Record deleted successfully',
	2=>'Error occured. Please try again.', 
	3=>'Record saved successfully.',
    4=>'Record updated successfully.', 
    5=>'All fields are required.' );
	$msg=$this->session->flashdata('message');

$flag    = isset($msg)?intval($msg):0;
$message ='';
if($flag){
  $message = $messages[$flag];
}


?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>codeigniter mongodb tutorial - view insert update delete records</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>/css/style.css" />
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="logo">
                <h3>
                 Codeigniter mongoDB Tutorial - View, insert update, delete records
                </h3>
            </div>
        </div>
        <div class="row">
            <div class="span12">
                <div class="mini-layout">
                   <form id="form1" name='form1' action="<?= site_url();?>/welcome/insert" method="post">
                   <input type='hidden' name='id' id='id' value="" />
                    <table>
                      <tr>
                        <td><input type='text' name='product_name' id='product_name' placeholder="Product Name" /></td>
                        <td><input type='text' name='price' id='price' placeholder="Price" /></td>
                        <td><input type='text' name='category' id='category' placeholder="Category" /></td>
                        <td><input class='btn' type='submit' name='btn' id='btn' value="Add Records" /></td>
                      </tr>
                    </table>
                   </form>
                    <h3>Products Listing</h3>
                    <p>
                     <?php if($flag == 2 || $flag == 5){ ?>
                        <div class="error"><?php echo $message; ?></div>
                      <?php  } elseif($flag && $flag != 2 ){ ?>
                        <div class="success"><?php echo $message; ?></div>
                      <?php  } ?>
                    </p>
                    <table class='table table-bordered'>
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Prodcut</th>
                          <th>Price</th>
                          <th>Category</th>
                          <th>Action</th>
                        </tr>
                     </thead>
                    <?php 
                    $i =1; 
                    foreach ($cur as $document) { ?>
                      <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $document->product_name;  ?></td>
                        <td><?php echo $document->price;  ?></td>
                        <td><?php echo $document->category;  ?></td>
                        <td><a class='editlink' data-id=<?php echo $document->_id; ?> href='javascript:void(0)'>Edit</a> |
                          <a onClick ='return confirm("Do you want to remove this record?");' href='<?=site_url().'welcome/delete/'.$document->_id; ?>'>Delete</td>
                      </tr>
                   <?php $i++;  
                    } 
                  ?>
                    </table>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script>
$(function(){
  $('.editlink').on('click', function(){
    var id = $(this).data('id');
    if(id){
		//alert('<?=site_url()?>welcome/record_ajax');
      $.ajax({
          method: 'POST',
          url: '<?=site_url()?>welcome/record_ajax',
          data: { id: id}
        })
        .done(function( result ) {
          result = $.parseJSON(result);
          $('#product_name').val(result['product_name']);
          $('#price').val(result['price']);
          $('#category').val(result['category']);
          $('#id').val(result['id']);
          $('#btn').val('Update Records');
          $('#form1').attr('action', '<?=site_url()?>welcome/edit');
        });
      }
    });
});

</script>
</body>
</html>
