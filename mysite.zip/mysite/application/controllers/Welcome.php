<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
    public function __construct() {
        parent::__construct();
      
    }
    
    public function index(){

$this->load->model('Main_model');
$filter=[];
$option=['sort' => ['_id' => 1],];
$data['cur']=$this->Main_model->search($filter,$option,'pro');
$this->load->view('welcome_message',$data);
    }
       public function insert()
	   {
  $product_name = '';
  $price        = 0;
  $category     = '';
  $btn=$this->input->post('btn');
  if(isset($btn)){
      $product_name = $this->input->post('product_name');
      $price        = $this->input->post('price');
      $category     = $this->input->post('category');
      $id           = $this->input->post('id');

      if(!$product_name || !$price || !$category){
      $this->session->set_flashdata('message',"5");
      }else{
		  $insertvalue=['product_name' =>$product_name, 'price'=>$price, 'category'=>$category];
         $result =$this->Main_model->insert($insertvalue,'pro');
          if($result->getInsertedCount()){
             $this->session->set_flashdata('message',"3");
          }else{
            $this->session->set_flashdata('message',"2");
          }
      }
  }
  redirect('welcome'); 
	   }
	   
	   public function edit()
	   {
	$product_name = '';
  $price        = 0;
  $category     = '';
  $flag         = 0;
  $btn=$this->input->post('btn');
  if(isset($btn)){
      $product_name = $this->input->post('product_name');
      $price        = $this->input->post('price');
      $category     = $this->input->post('category');
      $id           = $this->input->post('id');

      if(!$product_name || !$price || !$category || !$id){
        $flag = 5;
      }else{
         
         $insertvalue=['$set' =>['product_name' =>$product_name, 'price'=>$price, 'category'=>$category]];
       $result =$this->Main_model->update($insertvalue,'pro',$id);

         if($result->getModifiedCount()){
             $this->session->set_flashdata('message',"4");
          }else{
            $this->session->set_flashdata('message',"2");
          }
      }
  }
  redirect('welcome'); 
	   }
	   public function record_ajax()
	   {
$id    = $this->input->post('id');
$result = array();
if($id){
  $filter = ['_id' => new MongoDB\BSON\ObjectID($id)];
  $option= ['projection' => ['_id' => 0],];
  $cursor =$this->Main_model->search($filter,$option,'pro');;
  foreach($cursor as $row){
    $result ['product_name'] = $row->product_name;
    $result ['price']        = $row->price;
    $result ['category']     = $row->category;
    $result ['id']           = $id;
  }
  echo json_encode($result);
	   }
	   }	  
 public function delete()
	   {
$id    = $this->uri->segment(3);
$tbl='pro';
$result=$this->Main_model->delet($id,$tbl);
$this->session->set_flashdata('message',"1");
redirect('welcome'); 
	   }
    
    
}
