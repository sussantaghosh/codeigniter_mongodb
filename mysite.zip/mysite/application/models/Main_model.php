<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Main_model extends CI_Model {

private $manager ;
	public function __construct() {
		parent::__construct(); 
$this->manager=new MongoDB\Driver\Manager("mongodb://localhost:27017");
	}
	
    function search($filter,$option,$tbl){
$filter = $filter;
$options = $option; 
$tbl=$tbl;
$query = new MongoDB\Driver\Query($filter, $options);
$cursor = $this->manager->executeQuery("onlinestore.$tbl", $query);
	return $cursor;
       exit;
    } 
	function insert($insertvalue,$tbl){
		$querystr=$insertvalue;
		$tbl=$tbl;
$insRec= new MongoDB\Driver\BulkWrite;
 $insRec->insert($querystr);
$writeConcern = new MongoDB\Driver\WriteConcern(MongoDB\Driver\WriteConcern::MAJORITY, 1000);
$result = $this->manager->executeBulkWrite("onlinestore.$tbl", $insRec, $writeConcern);
   return $result ;
     exit;
	   }	
	   function update($insertvalue,$tbl,$id){
		$querystr=$insertvalue;
		$id=$id;
		$tbl=$tbl;
$insRec= new MongoDB\Driver\BulkWrite;
 $insRec->update(['_id'=>new MongoDB\BSON\ObjectID($id)],$querystr, ['multi' => false, 'upsert' => false]);
$writeConcern = new MongoDB\Driver\WriteConcern(MongoDB\Driver\WriteConcern::MAJORITY, 1000);
$result = $this->manager->executeBulkWrite("onlinestore.$tbl", $insRec, $writeConcern);
	  return $result ;
	    exit;
	   }
	   function delet($id,$tbl){
		$id=$id;
		$tbl=$tbl;
$insRec= new MongoDB\Driver\BulkWrite;
 $insRec->delete(['_id' =>new MongoDB\BSON\ObjectID($id)], ['limit' => 1]);
$writeConcern = new MongoDB\Driver\WriteConcern(MongoDB\Driver\WriteConcern::MAJORITY, 1000);
$result = $this->manager->executeBulkWrite("onlinestore.$tbl", $insRec, $writeConcern);
	  return $result ;
	    exit;
	   }
	
 

}